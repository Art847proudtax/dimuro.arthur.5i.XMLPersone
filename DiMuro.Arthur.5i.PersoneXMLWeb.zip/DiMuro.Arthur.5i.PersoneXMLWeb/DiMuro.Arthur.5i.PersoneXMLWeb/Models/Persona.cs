﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DiMuro.Arthur._5i.PersoneXMLWeb
{
    public class Persona
    {
        public string nome { get; set; }
        public string cognome { get; set; }
        public string indirizzo { get; set; }
        public string numero { get; set; }
        public Persona(XElement e)
        {
            nome = e.Attribute("Nome").Value;
            cognome = e.Attribute("Cognome").Value;
            indirizzo = e.Attribute("Indirizzo").Value;
            numero = e.Attribute("Numero").Value;

        }
    }
}
